
module.exports = [   
    about = [
        row_1 = [
            {
                "id": 1,
                "title": "A-title-1",
                "src": "Asrc1",
                "order": ""
            },
            {
                "id": 2,
                "title": "B-title-2",
                "src": "Bsrc2",
                "order": ""
            },
            {
                "id": 3,
                "title": "Ctitle-3",
                "src": "Csrc3",
                "order": ""
            }
        ],
        row_2 = [
            {
                "id": 1,
                "title": "title-1",
                "src": "src1",
                "alt": ""
                },
                {
                "id": 2,
                "title": "title-2",
                "src": "src2",
                "alt": ""
                },
                {
                "id": 3,
                "title": "title-3",
                "src": "src3",
                "alt": ""
                }
            ]
        ]
]